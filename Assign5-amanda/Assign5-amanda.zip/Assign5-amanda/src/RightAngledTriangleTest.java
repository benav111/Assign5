import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * Unit tests for RightAngledTriangle
 * @author Amanda
 * @version 4/18/2016
 */
public class RightAngledTriangleTest {

	/**
     * A tolerance to use when comparing double values for equality.
     */
    private static final double TOLERANCE = .0001;
	/**
	 * RightAngledTriangle object used in testing
	 */
	private RightAngledTriangle rightAngle;
	
	
	/**
	 * The measurement of sideA length
	 */
	private double sideA;
	
	/**
	 * The measurement of sideB length
	 */
	private double sideB;
	
	/**
	 * The measurement of sideC length
	 */
	private double sideC;
	
	/**
	 * Setup the initial values for the Tests
	 * @throws java.lang.Exception
	 */
	@Before// This method will run before each test method
	public void setUp() throws Exception {
		sideA = 3;
		sideB = 4;
		sideC = 5;
		
		rightAngle = new RightAngledTriangle(sideA, sideB, sideC);
		
	}

	/**
	 * Test method for {@link RightAngledTriangle#validateInput(double, double, double)}.
	 */
	@Test
	public void testValidateInput() {
		assertEquals("ValidateInput failed!", true, rightAngle.validateInput(sideA, sideB, sideC));
		assertEquals("ValidateInput Failed", false, rightAngle.validateInput(0, 0, 5));
		
	}

	/**
	 * Test method for {@link RightAngledTriangle#RightAngledTriangle(double, double, double)}.
	 */
	@Test
	public void testRightAngledTriangle() {
		assertEquals("Constructor failed", 3.0, rightAngle.sideA, TOLERANCE);
		assertEquals("Constructor failed", 4.0, rightAngle.sideB, TOLERANCE);
		assertEquals("Constructor failed", 5.0, rightAngle.sideC, TOLERANCE);
	}

	/**
	 * Test method for {@link RightAngledTriangle#getArea()}.
	 */
	@Test
	public void testGetArea() {
		assertEquals("getArea Failed!", 6.0, rightAngle.getArea(), TOLERANCE);
	}

}
