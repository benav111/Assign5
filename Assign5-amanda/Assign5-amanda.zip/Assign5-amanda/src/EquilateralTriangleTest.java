import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * 
 */

/**
 * @author Amanda
 * @version 4/18/2016
 */
public class EquilateralTriangleTest {
	

	/**
     * A tolerance to use when comparing double values for equality.
     */
    private static final double TOLERANCE = .0001;
	/**
	 * EquilateralTriangle object used in testing
	 */
	private EquilateralTriangle equilateral;
	
	/**
	 * The measurement of sideA length
	 */
	private double sideA;
	
	/**
	 * The measurement of sideB length
	 */
	private double sideB;
	
	/**
	 * The measurement of sideC length
	 */
	private double sideC;
	
	/**Set up inputs for testing
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		sideA = 2;
		sideB = 2;
		sideC = 2;
		equilateral = new EquilateralTriangle(sideA);
		
	}


	/**
	 * Test method for {@link EquilateralTriangle#validateInput(double, double, double)}.
	 */
	@Test
	public void testValidateInput() {
		assertEquals("ValidateInput Failed!", true, equilateral.validateInput(sideA, sideB, sideC));
	}

	/**
	 * Test method for {@link EquilateralTriangle#EquilateralTriangle(double)}.
	 */
	@Test
	public void testEquilateralTriangle() {
		assertEquals("Constructor failed", 2.0, equilateral.sideA, TOLERANCE);
		assertEquals("Constructor failed", 2.0, equilateral.sideB, TOLERANCE);
		assertEquals("Constructor failed", 2.0, equilateral.sideC, TOLERANCE);
	}

	/**
	 * Test method for {@link EquilateralTriangle#getArea()}.
	 */
	@Test
	public void testGetArea() {
		assertFalse("getArea failed!", 0 == equilateral.getArea());
	}

}
