/**
 * SE320- Individual Assignment 5
 * 
 * Represents a Right Angled Triangle
 * @author Amanda
 * @version 4/20/2016
 */
public class RightAngledTriangle extends Triangle {
    
	/**
	 * @param width width of the triangle
	 * @param height height of the triangle
	 * @param hypotenuse hypotenuse of the triangle
	 * @throws Exception Throws an exception if the input is invalid
	 */
    RightAngledTriangle(double width, double height, double hypotenuse) throws Exception 
    {	
    	super(width, height, hypotenuse);
    }
    
    /**Check if the inputs are valid
     * @param sideA the first side of the triangle
     * @param sideB the second side of the triangle
     * @param sideC the third side of the triangle
     * @return Whether or not the input is valid
     */
    public boolean validateInput(double sideA, double sideB, double sideC) 
    {
            return ((sideC * sideC) == ((sideA * sideA) + (sideB * sideB)));
                
    }

  /**The area of the triangle
   * @return the area of the triangle
   */
    public double getArea() {
        return ((sideA * sideB) / 2);
    }

}
