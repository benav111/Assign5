import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * 
 */

/**
 * @author Amanda
 *@version 4/18/2016
 */
public class TriangleTest {
	/**
     * A tolerance to use when comparing double values for equality.
     */
    private static final double TOLERANCE = .0001;

	/**
	 * Triangle object used in testing
	 */
	private Triangle triangle;
	
	/**
	 * The measurement of sideA length
	 */
	private double sideA;
	
	/**
	 * The measurement of sideB length
	 */
	private double sideB;
	
	/**
	 * The measurement of sideC length
	 */
	private double sideC;
	
	/**Set up inputs for testing
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		sideA = 2;
		sideB = 3;
		sideC = 4;
		triangle = new Triangle(sideA, sideB, sideC);
	}

	/**
	 * Test method for {@link Triangle#Triangle(double, double, double)}.
	 */
	@Test
	public void testTriangle() {
		assertEquals("Constructor failed", 2.0, triangle.sideA, TOLERANCE);
		assertEquals("Constructor failed", 3.0, triangle.sideB, TOLERANCE);
		assertEquals("Constructor failed", 4.0, triangle.sideC, TOLERANCE);	
	}

	/**
	 * Test method for {@link Triangle#validateInput(double, double, double)}.
	 */
	@Test
	public void testValidateInput() {
		assertEquals("ValidateInput failed!", true, triangle.validateInput(sideA, sideB, sideC));
	}

	/**
	 * Test method for {@link Triangle#getSideA()}.
	 */
	@Test
	public void testGetSideA() {
		assertEquals("getSideA failed!", 2.0, triangle.getSideA(), TOLERANCE);
	}

	/**
	 * Test method for {@link Triangle#getSideB()}.
	 */
	@Test
	public void testGetSideB() {
		assertEquals("getSideB failed!", 3.0, triangle.getSideB(), TOLERANCE);
	}

	/**
	 * Test method for {@link Triangle#getSideC()}.
	 */
	@Test
	public void testGetSideC() {
		assertEquals("getSideC failed!", 4.0, triangle.getSideC(), TOLERANCE);
	}

	/**
	 * Test method for {@link Triangle#getPerimeter()}.
	 */
	@Test
	public void testGetPerimeter() {
		assertEquals("getPerimeter failed!", 9.0, triangle.getPerimeter(), TOLERANCE);
	}

	/**
	 * Test method for {@link Triangle#getArea(double, double, double)}.
	 */
	@Test
	public void testGetArea() {
		try
		{
			Triangle tri = new Triangle(2,2,2);
			assertEquals("getArea failed!", Math.sqrt(3), tri.getArea(), TOLERANCE);
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

}
