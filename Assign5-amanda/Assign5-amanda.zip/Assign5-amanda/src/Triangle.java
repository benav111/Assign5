
/**
 * SE320- Individual Assignment 5
 * 
 * Represents a Triangle
 * @author Amanda
 * @version 4/18/2016
 */
public class Triangle {
    
	/**
	 * side A of the triangle
	 */
    protected double sideA;
    
    /**
	 * side B of the triangle
	 */
    protected double sideB;
    
    /**
	 * side C of the triangle
	 */
    protected double sideC;
    
 
    
    /**
     * constructs the triangle given the length of the sides
     * @param sideA the first side of the triangle
     * @param sideB the second side of the triangle
     * @param sideC the third side of the triangle
     */
    Triangle(double sideA, double sideB, double sideC) throws Exception {
        
        if (!validateInput(sideA, sideB, sideC)) {
            throw new Exception("Invalid Inputs");
        }

        this.sideA = sideA;
        this.sideB = sideB;
        this.sideC = sideC;
    }
    
   /**
    * validate the input
    * @param sideA the first side of the triangle
    * @param sideB the second side of the triangle
    * @param sideC the third side of the triangle
    * @return whether or not the input is valid
    */
    public boolean validateInput(double sideA, double sideB, double sideC) {
    	//changed from else to return false
       return ( sideA > 0 && sideB > 0 && sideC > 0);
    }
   
    /**
     * @return the first side of the triangle
     */
    public double getSideA() {
        return this.sideA;
    }
    
    /*
     * @return the second side of the triangle
     */
    public double getSideB() {
        return this.sideB;
    }
    
    /**
     * @return the third side of the triangle
     */
    public double getSideC() {
        return this.sideC;
    }
    
    /**
     * @return the perimeter of the triangle
     */
    public double getPerimeter() {
        return sideA + sideB + sideC;
    }
    
    /**
     * @param sideA the first side of the triangle
     * @param sideB the second side of the triangle
     * @param sideC the third side of the triangle
     * @return the area of the triangle
     */
    public double getArea() {
        double p = getPerimeter()/2;
        return Math.sqrt(p * (p - sideA) * (p - sideB) * (p - sideC));
    }

}
